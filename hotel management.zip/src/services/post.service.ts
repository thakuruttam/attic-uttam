import { ObjectId } from "mongoose";
import Logger from "../../core/Logger";
import Table from "../models/Bill";
export class _Table_Services {
  async createTable() {
    console.log();
  }
}

export const Table_Services = new _Table_Services();
