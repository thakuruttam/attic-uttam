import { Request, Response } from "express";
import Bill from "../models/Bill";

export class _BillController {
  async createBill(req: Request, res: Response) {
    console.log(req.body);
    try {
      const newBill = new Bill({
        tableNumber: req.body.tableNumber,
        totalBill: req.body.itemPrice,
        items: [{ itemName: req.body.itemName, itemPrice: req.body.itemPrice }],
        phoneNumber: req.body.phoneNumber,
        name: req.body.name,
        billed_by: req.body.billed_by,
        billComplete: req.body.billComplete,
      });
      await newBill.save();
      res.status(200).json({ msg: "success" });
    } catch (error) {
      res.json(error);
    }
  }

  async endBill(req: Request, res: Response) {
    console.log(req.body);

    try {
      const filter = { _id: req.body.id };
      const update = { billComplete: true };
      await Bill.findOneAndUpdate(filter, update);
      let result = await Bill.findOne({ _id: req.body.id });
      res.status(200).json({ result });
    } catch (error) {
      res.json(error);
    }
  }

  async changeTable(req: Request, res: Response) {
    console.log(req.body);

    try {
      const filter = { _id: req.body.id };
      const update = { tableNumber: req.body.newtable };
      await Bill.findOneAndUpdate(filter, update);
    } catch (error) {
      res.json(error);
    }
  }

  async getBillById(req: Request, res: Response) {
    try {
      let result = await Bill.findOne({ _id: req.query.id });
      res.status(200).json({ result });
    } catch (error) {
      res.json(error);
    }
  }
  async getBillByPhoneNumber(req: Request, res: Response) {
    try {
      let result = await Bill.find({ phoneNumber: req.query.phoneNumber });
      res.status(200).json({ result });
    } catch (error) {
      res.json(error);
    }
  }
}
export const BillController = new _BillController();
