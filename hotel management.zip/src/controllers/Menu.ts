import { Request, Response } from "express";
import Table from "../models/Bill";
import Menu from "../models/Menu";

export class _MenuController {
  async addMenu(req: Request, res: Response) {
    let { dishName, fullrate, halfrate, quarterrate } = req.body;
    console.log(req.body.dishName);
    try {
      const newMenu = new Menu({
        dishName: dishName,
        fullrate: fullrate,
        halfrate: halfrate,
        quarterrate: quarterrate,
      });
      await newMenu.save();
      res.status(200).json({ msg: "success" });
    } catch (error) {
      res.json(error);
    }
  }

  async getMenu(req: Request, res: Response) {
    try {
      let result = await Menu.find({});
      res.status(200).json({ result });
    } catch (error) {
      res.json(error);
    }
  }

  async getMenuById(req: Request, res: Response) {
    try {
      var dish = req.query.dishName;
      let result = await Menu.findOne({ dishName: dish });
      res.status(200).json({ result });
    } catch (error) {
      res.json(error);
    }
  }
  async updateDish(req: Request, res: Response) {
    try {
      if (req.body.dishName && req.body.newfullrate) {
        const filter = { dishName: req.body.dishName };
        const update = { fullrate: req.body.newfullrate };
        await Menu.findOneAndUpdate(filter, update);
      }

      if (req.body.newhalfRate && req.body.dishName) {
        const filter = { dishName: req.body.dishName };
        const update = { halfrate: req.body.newhalfRate };

        await Menu.findOneAndUpdate(filter, update);
      }

      if (req.body.newquarterrate && req.body.dishName) {
        const filter = { dishName: req.body.dishName };
        const update = { quarterrate: req.body.quarterrate };

        await Menu.findOneAndUpdate(filter, update);
      }
      if (req.body.newdishName) {
        const filter = { dishName: req.body.dishName };
        const update = { dishName: req.body.newdishName };

        await Menu.findOneAndUpdate(filter, update);
      }

      res.status(200).json("updated Succesfully");
    } catch (error) {
      res.json(error);
    }
  }
}
export const MenuController = new _MenuController();
