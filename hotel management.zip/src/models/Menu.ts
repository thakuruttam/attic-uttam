import { Schema, model } from "mongoose";

const MenuSchema = new Schema(
  {
    dishName: { type: String },
    fullrate: { type: Number },
    halfrate: { type: Number },
    quarterrate: { type: Number },
  },
  { timestamps: true }
);

export default model("Menu", MenuSchema);
