import { Schema, model } from "mongoose";

const BillSchema = new Schema(
  {
    tableNumber: { type: Number },
    totalBill: { type: Number },
    items: [{ itemName: { type: String }, itemPrice: { type: Number } }],
    phoneNumber: { type: Number },
    name: { type: String },
    billed_by: { type: String },
    billComplete: { type: Boolean },
  },
  { timestamps: true }
);

export default model("Bill", BillSchema);
