import { Schema, model } from "mongoose";

const UserSchema = new Schema(
  {
    email: { type: String, required: true, unique: true, index: true },
    googleId: { type: String, required: true },
    firstName: { type: String },
    userType: { type: String, required: true, default: "patreon" },
    bio: { type: String },
    country: { type: String, required: true, default: "India" },
    dob: { type: Date },
    industry: { type: String },
    isComapany: { type: Boolean, default: false },
    followingMe: [{ type: Schema.Types.ObjectId }],
    followedByMe: [{ type: Schema.Types.ObjectId }],
    lastName: { type: String },
    profileImage: { type: String },
    coverImage: { type: String },
    socialUrl: [{ platform: { type: String }, url: { type: String } }],
    posts: [{ type: Schema.Types.ObjectId }],
    createdAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export default model("User", UserSchema);
