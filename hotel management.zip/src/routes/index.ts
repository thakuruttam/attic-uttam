import express from "express";
import { BillController } from "../controllers/Bill";
import { MenuController } from "../controllers/Menu";
export const route = express.Router();

route.post("/addDish", MenuController.addMenu);
route.get("/getMenu", MenuController.getMenu);
route.get("/getMenuByName", MenuController.getMenuById);
route.put("/updateMenu", MenuController.updateDish);

//----------------Bill------------------

route.post("/startBill", BillController.createBill);
route.post("/endbill", BillController.endBill);
route.put("/changeTable", BillController.changeTable);
route.get("/getBillByNumber", BillController.getBillByPhoneNumber);
